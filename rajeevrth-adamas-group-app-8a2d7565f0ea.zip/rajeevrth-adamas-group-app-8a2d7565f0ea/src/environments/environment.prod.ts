export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyA_lF7pADyYP3mEjuv6TkF5Aj4TdzdsKSc',
    authDomain: 'adamas-group-app.firebaseapp.com',
    projectId: 'adamas-group-app',
    storageBucket: 'adamas-group-app.appspot.com',
    messagingSenderId: '769335204234',
    appId: '1:769335204234:web:8bd9eb6252be9a65959073',
  },
};
