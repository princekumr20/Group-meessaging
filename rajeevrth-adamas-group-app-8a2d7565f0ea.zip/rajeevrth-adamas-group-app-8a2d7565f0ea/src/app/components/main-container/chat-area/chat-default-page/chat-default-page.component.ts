import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat-default-page',
  templateUrl: './chat-default-page.component.html',
  styleUrls: ['./chat-default-page.component.scss']
})
export class ChatDefaultPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
