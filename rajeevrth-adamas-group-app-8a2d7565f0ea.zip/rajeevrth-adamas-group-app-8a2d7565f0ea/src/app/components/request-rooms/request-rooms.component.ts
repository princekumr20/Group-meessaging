import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-rooms',
  templateUrl: './request-rooms.component.html',
  styleUrls: ['./request-rooms.component.scss'],
})
export class RequestRoomsComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}

  // Fetch All the rooms
}
